import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import joblib

df = pd.read_csv('../data/dataset.csv')
X = df[['hours_studied','attendance','previous_score']]
y = df['pass']

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)

model=LogisticRegression()
model.fit(X_train,y_train)

y_pred=model.predict(X_test)
print("Model Accuracy:",accuracy_score(y_test,y_pred))

joblib.dump(model,'model.pkl')
