import joblib
model=joblib.load('model.pkl')
new_data=[[5,75,60]]
print("Prediction:",model.predict(new_data)[0])
