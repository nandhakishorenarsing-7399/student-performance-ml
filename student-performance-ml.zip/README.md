# Student Performance Prediction using ML

Run:
pip install -r requirements.txt
cd src
python train.py
python predict.py
